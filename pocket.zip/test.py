from tkinter import *
import csv
import subprocess

root = Tk()
root.title("Pocket Baseline")
root.iconbitmap('logo.ico')
root.geometry("600x300")
bnum=4
jnum=100
name_label = Label(root, text="Search", padx=2, pady=5).grid(row=1, column=0)
name_label = Label(root, text="SID", padx=2, pady=5).grid(row=bnum-1, column=2)
name_label = Label(root, text="Hostname", padx=15, pady=5).grid(row=bnum-1, column=3)
name_label = Label(root, text="IP", padx=10, pady=5).grid(row=bnum-1, column=4)
name_label = Label(root, text="Mobauser", padx=10, pady=5,width=10).grid(row=bnum-1, column=5)
name_label= Label(root, text="url", padx=10, pady=20).grid(row=jnum, column=1)

p=StringVar()
p.set("putty")
frame=Frame(root,borderwidth=10)
my_radio = Radiobutton(frame, text="putty", variable=p, value="putty").grid(row=1,column=3)
my_radio = Radiobutton(frame, text="moba", variable=p, value="moba").grid(row=1,column=4)
my_radio = Radiobutton(frame, text="win", variable=p, value="win").grid(row=1,column=5)
my_radio = Radiobutton(frame, text="gui", variable=p, value="gui").grid(row=1,column=6)
labLst = []
root.mainloop()