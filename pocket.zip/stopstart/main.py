from suds.client import Client
import ssl,paramiko,sqlite3,time
from cryptography.fernet import Fernet

def processControl(hostname,mydict,flag):
    conn = sqlite3.connect(database)
    mainbreak=False
    #try:
    for key in mydict:
        #print("**********checking***********")
        print("Checking the Status of services on " + key + " of server " + hostname)
        print()
        c = conn.cursor()
        try:
            c.execute("select username,password from users where hostname=? and username=? LIMIT 1 ",
                      (hostname, mydict[key]))
            (user, secret) = c.fetchone()
        except:
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            print("!!   User:"+mydict[key]+" for instance "+key+" Does not exists in the DB!   !!")
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            if flag =='status':
                continue
            else:
                print("Trying to "+flag+" "+mydict[key]+"on server"+hostname+" but unable to find the entry in DB hence exiting the server. Please check manually")
                break
        if user:
            password = decryptSecret(secret).decode()

        if hasattr(ssl, '_create_unverified_context'):
            ssl._create_default_https_context = ssl._create_unverified_context
        cli = Client('https://{}:5{}14/?wsdl'.format(hostname, key[-2:]), username=mydict[key],
                     password=password)

        if flag == 'status':
            length = len(cli.service.GetProcessList()[0])
            result = cli.service.GetProcessList()[0]
            for i in range(length):
                print(result[i].description + "--->" + result[i].dispstatus)
            print()
        elif flag == 'start':
            cli.service.Start()
            timeout_start = time.time()
            while True:
                time.sleep(5)
                length = len(cli.service.GetProcessList()[0])
                result = cli.service.GetProcessList()[0]
                count=0
                for i in range(length):
                    if "GREEN" in result[i].dispstatus:
                        print(result[i].description + "--->" + result[i].dispstatus)
                        count+=1
                if count == length:
                    print("Process are up")
                    break

                if time.time() > timeout+timeout_start:
                    mainbreak=True
                    print("Time out occured in starting")
                    break
        elif flag == 'stop':
            cli.service.Stop()
            timeout_start = time.time()
            while True:
                length = len(cli.service.GetProcessList()[0])
                result = cli.service.GetProcessList()[0]
                count = 0
                for i in range(length):
                    if "GRAY" in result[i].dispstatus:
                        print(result[i].description + "--->" + result[i].dispstatus)
                        count += 1
                if count == length:
                    print("Process are down")
                    break

                time.sleep(5)
                if time.time() > timeout + timeout_start:
                    mainbreak = True
                    print("Time out occured in Stopping")
                    break
        if mainbreak:
            print("Some issue with"+flag+" on host"+hostname+"Hence not proceeding with other instances"+flag)
            break
        c.close()
    #except:
        #print("Dictionary is Empty. No data being fetched from Server.May be VPN or host connection issue")

def orderDict(mydict,ord):
    dict2 = {}
    for key in mydict:
        if key.startswith("ASCS") or key.startswith("SCS"):
            dict2[key] = 50
        elif key.startswith('D'):
            dict2[key] = 25
        elif key.startswith('HDB'):
            dict2[key] = 100
        else:
            dic2[key]=0
    if ord=='asc':
        return dict(sorted(mydict.items(), key=lambda kv: dict2[kv[0]]))
    elif ord=='des':
        return dict(reversed(sorted(mydict.items(), key=lambda kv: dict2[kv[0]])))


def checkInstace(hostname,username,password):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(hostname, port=22, username=username,password=password, timeout=3)

        # Execute command on SSH terminal
        # using exec_command
        stdin, stdout, stderr = ssh.exec_command('ps -ef | grep srv | grep -v grep | grep -v hostctrl | grep -v SMDA')
        #print(stderr.read())
        if stderr.read() == b'':
            mydict={}
            print("*********************"+hostname+"*******************************")
            print("Dectected Instances")
            print("\033[4mInstance\033[0m"+" "+"\033[4mInst No.\033[0m"+" "+"\033[4mService User\033[0m")
            for line in stdout.readlines():
                if line:
                    instance = line.split()[7].split('/')[4]
                    instNo = line.split()[7].split('/')[4][-2:]
                    serUser = line.split()[0]
                    print(instance.ljust(9), instNo.ljust(8), serUser)
                    mydict[instance] = serUser
            return mydict
        else:
            print(stderr.read())
    except:
        print("Unable to connect to "+hostname+"May be hostname or VPN issue")

def decryptSecret(secret):
    key = '3aFkjY7tG_zaAepHLubVk1C8ikecW6AzRPKkk5_9oZU='
    cipher_suite = Fernet(key)
    return cipher_suite.decrypt(secret)

database='host.db'
timeout = 300

def main():
    #servers=['ussltccsl1911.solutions.glbsnet.com','ussltccsl1910.solutions.glbsnet.com','ussltcsnl1227.solutions.glbsnet.com']
    servers = ['ussltcsnl1227.solutions.glbsnet.com']
    conn=sqlite3.connect(database)
    c=conn.cursor()
    for server in servers:
        try:
            c.execute("select username,password from users where hostname=? LIMIT 1 ",(server,))
            (user,secret)=c.fetchone()
        except:
            print("*********************" + server + "*******************************")
            print("Hostname:"+server+" does not exist in the database")
            print()
            continue
        if user:
            password=decryptSecret(secret)
            maindict=checkInstace(hostname=server,username=user,password=password)
            print(maindict) #To be removed

            flag='start'
            if flag == 'stop':
                maindict=orderDict(maindict,'asc')
                processControl(server, maindict, flag)
            if flag == 'start':
                maindict = orderDict(maindict, 'des')
                processControl(server, maindict, flag)
            elif flag == 'status':
                maindict = orderDict(maindict, 'des')
                processControl(server, maindict,flag)

            print(maindict)

        #else:
            #print("User="+user+ " does not exist in DB for the host="+server+"Check the user or recheck hostname")
    c.close()

if __name__ == '__main__':
    main()


