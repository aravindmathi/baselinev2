import sqlite3
from cryptography.fernet import Fernet
import os

# c.execute("""CREATE TABLE users(
#              username text not NULL PRIMARY KEY,
#              hostname text not NULL,
#              password text not NULL
#      )""")

"""To Delete a row"""
#c.execute("delete from users where username=':username'")
#conn.commit()

def getTheDetails():
    username = input("enter the sidadm user")
    if len(username) == 6 and username.isalnum() and 'adm' in username:
        print("success")
    else:
        print("Entered User is not correct")
        os._exit(1)

    hostname = input("Enter the hostname")
    password = input("Enter the password")
    if hostname and password:
        return username,hostname,password
    else:
        print("Either Hostname of password is null")
        os._exit(1)

def main():

    database='host.db'
    key = '3aFkjY7tG_zaAepHLubVk1C8ikecW6AzRPKkk5_9oZU='
    cipher_suite = Fernet(key)

    # Connecting to DB
    conn = sqlite3.connect(database)
    c = conn.cursor()
    username,hostname,password=getTheDetails()

    password=password.encode()
    encoded_text = cipher_suite.encrypt(password)
    # try:
    #     c.execute("Insert into users VALUES(:username,:hostname,:password)",{'username': username, 'hostname': hostname, 'password': encoded_text})
    #     conn.commit()
    # except:
    #      print("Unable to Insert the entries possibly Duplicate Primary Key")

    # c.execute("select * from users where hostname=?",('ussltccsl1911.solutions.glbsnet.com',))
    # for row in c.fetchall():
    #     print(row)
    #     print(cipher_suite.decrypt(row[2]))
    conn.close()
if __name__ == '__main__':
    main()